
export type Difficulty = 1 | 2 | 3;

export type StudyGroupType = 'Alpha Integrals' | 'Vector Vanguards' | 'Newton\'s Nomads' | 'None';

export interface StudyGroup {
  id: string;
  name: StudyGroupType;
  icon: string;
  code: string;
  color: string;
}

export interface Profile {
  name: string;
  motivation: string;
  group: StudyGroupType;
  avatar: string;
  correctAnswers: number;
  totalAttempts: number;
  dailyCorrectCount: number; // For "5 questions a day" goal
  lastResetDate: string; // ISO string to track daily resets
  dailyGoalReached: boolean; // Has already claimed the bonus for today
}

export interface MathProblem {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  tips: string;
  workingSteps: string;
  topic: string;
  difficulty: Difficulty;
}

export interface Reward {
  id: string;
  name: string;
  pointsNeeded: number;
  redeemed: boolean;
  createdAt: number;
}

export interface MistakeRecord {
  problem: MathProblem;
  addedAt: number;
}

export interface DiscussionComment {
  id: string;
  authorName: string;
  authorAvatar: string;
  text: string;
  createdAt: number;
}

export interface DiscussionPost {
  id: string;
  groupName: StudyGroupType;
  authorName: string;
  authorAvatar: string;
  problem: MathProblem;
  timestamp: number;
  comments: DiscussionComment[];
}

export enum GameState {
  HOME = 'HOME',
  PRACTICE = 'PRACTICE',
  REWARDS = 'REWARDS',
  NOTEBOOK = 'NOTEBOOK',
  PROFILE = 'PROFILE',
  RANKINGS = 'RANKINGS',
  GROUP = 'GROUP'
}

export const STUDY_GROUPS: StudyGroup[] = [
  { id: 'alpha', name: 'Alpha Integrals', icon: '∫', code: 'ALPHA', color: 'blue' },
  { id: 'vector', name: 'Vector Vanguards', icon: '→', code: 'VECTOR', color: 'emerald' },
  { id: 'newton', name: 'Newton\'s Nomads', icon: '🍎', code: 'NEWTON', color: 'purple' }
];

export const AVATARS = ['👨‍🏫', '👩‍🔬', '🧙‍♂️', '🤖', '🦊', '🚀', '🧠', '🎓'];
