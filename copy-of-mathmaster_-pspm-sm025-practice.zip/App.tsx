
import React, { useState, useEffect } from 'react';
import { GameState, Reward, Profile, MistakeRecord, MathProblem, AVATARS, DiscussionPost, DiscussionComment } from './types';
import Header from './components/Header';
import Home from './components/Home';
import MathPractice from './components/MathPractice';
import RewardSystem from './components/RewardSystem';
import MistakeNotebook from './components/MistakeNotebook';
import ProfilePage from './components/ProfilePage';
import RankingPage from './components/RankingPage';
import GroupPage from './components/GroupPage';

const App: React.FC = () => {
  const [gameState, setGameState] = useState<GameState>(GameState.HOME);
  
  const [points, setPoints] = useState<number>(() => {
    const saved = localStorage.getItem('math_points');
    return saved ? parseInt(saved, 10) : 0;
  });

  const [rewards, setRewards] = useState<Reward[]>(() => {
    const saved = localStorage.getItem('math_rewards');
    return saved ? JSON.parse(saved) : [];
  });

  const [profile, setProfile] = useState<Profile>(() => {
    const saved = localStorage.getItem('math_profile');
    const today = new Date().toDateString();
    
    if (saved) {
      const parsed: Profile = JSON.parse(saved);
      // Daily reset logic on load
      if (parsed.lastResetDate !== today) {
        return {
          ...parsed,
          dailyCorrectCount: 0,
          dailyGoalReached: false,
          lastResetDate: today
        };
      }
      return parsed;
    }
    
    return { 
      name: '', 
      motivation: '', 
      group: 'None',
      avatar: AVATARS[0],
      correctAnswers: 0,
      totalAttempts: 0,
      dailyCorrectCount: 0,
      dailyGoalReached: false,
      lastResetDate: today
    };
  });

  const [mistakeNotebook, setMistakeNotebook] = useState<MistakeRecord[]>(() => {
    const saved = localStorage.getItem('math_notebook');
    return saved ? JSON.parse(saved) : [];
  });

  const [discussionPosts, setDiscussionPosts] = useState<DiscussionPost[]>(() => {
    const saved = localStorage.getItem('math_discussions');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('math_points', points.toString());
  }, [points]);

  useEffect(() => {
    localStorage.setItem('math_rewards', JSON.stringify(rewards));
  }, [rewards]);

  useEffect(() => {
    localStorage.setItem('math_profile', JSON.stringify(profile));
  }, [profile]);

  useEffect(() => {
    localStorage.setItem('math_notebook', JSON.stringify(mistakeNotebook));
  }, [mistakeNotebook]);

  useEffect(() => {
    localStorage.setItem('math_discussions', JSON.stringify(discussionPosts));
  }, [discussionPosts]);

  const addPoints = (amount: number) => {
    setPoints(prev => prev + amount);
    
    setProfile(prev => {
      const newDailyCount = prev.dailyCorrectCount + 1;
      let bonus = 0;
      let goalReached = prev.dailyGoalReached;

      // Award 50 bonus points for reaching the daily goal of 5 questions
      if (newDailyCount === 5 && !goalReached) {
        bonus = 50;
        goalReached = true;
      }

      if (bonus > 0) {
        setPoints(p => p + bonus);
      }

      return {
        ...prev,
        correctAnswers: prev.correctAnswers + 1,
        totalAttempts: prev.totalAttempts + 1,
        dailyCorrectCount: newDailyCount,
        dailyGoalReached: goalReached
      };
    });
  };

  const handleIncorrectAttempt = () => {
    setProfile(prev => ({
      ...prev,
      totalAttempts: prev.totalAttempts + 1
    }));
  };

  const addReward = (name: string, cost: number) => {
    const newReward: Reward = {
      id: Math.random().toString(36).substr(2, 9),
      name,
      pointsNeeded: cost,
      redeemed: false,
      createdAt: Date.now(),
    };
    setRewards(prev => [...prev, newReward]);
  };

  const redeemReward = (id: string) => {
    const reward = rewards.find(r => r.id === id);
    if (reward && points >= reward.pointsNeeded) {
      setPoints(prev => prev - reward.pointsNeeded);
      setRewards(prev => prev.map(r => r.id === id ? { ...r, redeemed: true } : r));
    }
  };

  const removeReward = (id: string) => {
    setRewards(prev => prev.filter(r => r.id !== id));
  };

  const handleMistake = (problem: MathProblem) => {
    setMistakeNotebook(prev => {
      if (prev.find(m => m.problem.id === problem.id)) return prev;
      return [{ problem, addedAt: Date.now() }, ...prev];
    });
  };

  const clearMistake = (problemId: string) => {
    setMistakeNotebook(prev => prev.filter(m => m.problem.id !== problemId));
  };

  const addDiscussionPost = (problem: MathProblem) => {
    const newPost: DiscussionPost = {
      id: Math.random().toString(36).substr(2, 9),
      groupName: profile.group,
      authorName: profile.name || 'Anonymous',
      authorAvatar: profile.avatar,
      problem,
      timestamp: Date.now(),
      comments: []
    };
    setDiscussionPosts(prev => [newPost, ...prev]);
  };

  const addCommentToPost = (postId: string, text: string) => {
    const newComment: DiscussionComment = {
      id: Math.random().toString(36).substr(2, 9),
      authorName: profile.name || 'Anonymous',
      authorAvatar: profile.avatar,
      text,
      createdAt: Date.now()
    };
    setDiscussionPosts(prev => prev.map(post => 
      post.id === postId 
        ? { ...post, comments: [...post.comments, newComment] }
        : post
    ));
  };

  const clearAllData = () => {
    localStorage.clear();
    setPoints(0);
    setRewards([]);
    setProfile({ 
      name: '', 
      motivation: '', 
      group: 'None',
      avatar: AVATARS[0],
      correctAnswers: 0,
      totalAttempts: 0,
      dailyCorrectCount: 0,
      dailyGoalReached: false,
      lastResetDate: new Date().toDateString()
    });
    setMistakeNotebook([]);
    setDiscussionPosts([]);
    setGameState(GameState.HOME);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#fbfcfd]">
      <Header 
        points={points} 
        setGameState={setGameState} 
        gameState={gameState} 
      />
      
      <main className="flex-grow container mx-auto px-4 py-8 max-w-5xl">
        {gameState === GameState.HOME && (
          <Home setGameState={setGameState} userProfile={profile} />
        )}
        
        {gameState === GameState.PRACTICE && (
          <MathPractice 
            onCorrectAnswer={() => addPoints(10)} 
            onMistake={handleMistake}
            onIncorrectAttempt={handleIncorrectAttempt}
          />
        )}
        
        {gameState === GameState.REWARDS && (
          <RewardSystem 
            rewards={rewards} 
            points={points} 
            onAddReward={addReward} 
            onRedeemReward={redeemReward}
            onRemoveReward={removeReward}
          />
        )}

        {gameState === GameState.NOTEBOOK && (
          <MistakeNotebook 
            records={mistakeNotebook}
            onCorrectRetry={(id) => {
              addPoints(5);
              clearMistake(id);
            }}
          />
        )}

        {gameState === GameState.PROFILE && (
          <ProfilePage 
            profile={profile}
            onUpdateProfile={setProfile}
            onClearData={clearAllData}
          />
        )}

        {gameState === GameState.RANKINGS && (
          <RankingPage userProfile={profile} />
        )}

        {gameState === GameState.GROUP && (
          <GroupPage 
            userProfile={profile} 
            onUpdateProfile={setProfile}
            mistakeNotebook={mistakeNotebook}
            discussionPosts={discussionPosts.filter(p => p.groupName === profile.group)}
            onAddDiscussionPost={addDiscussionPost}
            onAddComment={addCommentToPost}
          />
        )}
      </main>

      <footer className="bg-white border-t py-6 mt-12">
        <div className="container mx-auto px-4 text-center text-gray-400 text-xs">
          &copy; 2025 MathMaster SM025 • Designed for Academic Excellence
        </div>
      </footer>
    </div>
  );
};

export default App;
