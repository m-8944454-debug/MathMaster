
import { GoogleGenAI, Type } from "@google/genai";
import { MathProblem, Difficulty } from "../types";

// Always use named parameter for initialization.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateMathProblem = async (topic: string, difficulty: Difficulty): Promise<MathProblem> => {
  const difficultyLabel = difficulty === 1 ? "Beginner (1 star)" : difficulty === 2 ? "Intermediate (2 stars)" : "Advanced (3 stars)";
  
  // Topic-specific syllabus deep-dive for the prompt
  const topicContexts: Record<string, string> = {
    "Numerical Solution": `
      - Newton-Raphson Method: Use formula xₙ₊₁ = xₙ - f(xₙ)/f'(xₙ). 
      - Include variations: different initial guesses (x₀), problems asking for a specific number of iterations, or finding roots to a certain number of decimal places.
      - Trapezoidal Rule: Use formula ∫ f(x) dx ≈ (h/2)[y₀ + yₙ + 2(y₁ + ... + yₙ₋₁)]. 
      - Include: finding 'h', creating tables of values, and estimating integrals with given 'n' (number of subintervals).`,
    "Integration": `
      - Techniques: Substitution (including linear and trigonometric substitutions), Integration by Parts (including repetitive parts), and Partial Fractions (proper and improper fractions).
      - Definite Integrals: Evaluating areas under a curve, between two curves, or between a curve and the y-axis.
      - Volume of Revolution: About the x-axis (V = π ∫ y² dx) and y-axis (V = π ∫ x² dy).
      - Focus on variety: mix algebraic, exponential, and trigonometric functions.`,
    "Vector": `
      - Basic: Magnitude, direction cosines, unit vectors, and operations.
      - Scalar (Dot) Product: a·b = |a||b|cosθ. Use to find angles between vectors or check for orthogonality.
      - Vector (Cross) Product: a×b. Use to find areas of triangles/parallelograms and unit vectors perpendicular to a plane.
      - Lines in 3D: Vector (r = a + tb), parametric, and symmetric equations.
      - Planes in 3D: Vector (r·n = a·n) and Cartesian (ax + by + cz = d) equations.
      - Intersection and Distance: Finding the angle between a line and a plane, or the intersection point of a line and a plane.`
  };

  const topicContext = topicContexts[topic] || "Follow the SM025 syllabus standard.";

  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `Generate a math problem for the Malaysian Matriculation Mathematics 2 (SM025) Semester 2 syllabus. 
    Topic: ${topic}. 
    Difficulty Level: ${difficultyLabel}.
    
    SYLLABUS REQUIREMENTS:
    ${topicContext}

    CRITICAL INSTRUCTION FOR MATHEMATICAL NOTATION:
    - DO NOT use dollar signs ($) or complex LaTeX delimiters.
    - Use standard mathematical Unicode characters:
      * Subscripts: x₁, x₂, xₙ, y₀, y₁
      * Superscripts: x², x³, eˣ, sin²θ
      * Symbols: ∫ (integral), √ (root), π (pi), θ (theta), ≈ (approx), ± (plus-minus), → (arrow), · (dot product), × (cross product), î, ĵ, k̂ (unit vectors), ⊥ (perpendicular).
      * Fractions: Use a/b notation (e.g., 1/2) or clear division (e.g., (x+1)/(x-2)).
    - Ensure the question looks like a formal examination paper question (PSPM style).

    Output Requirements (JSON):
    - question: The problem statement. Be creative and vary the phrasing.
    - options: 4 clear multiple choice options. Distractors should represent common calculation errors.
    - correctIndex: 0-3.
    - tips: A helpful conceptual hint.
    - workingSteps: Step-by-step solution showing the application of the correct formula.
    - explanation: Brief explanation of the final step or key concept.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          question: { type: Type.STRING },
          options: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            minItems: 4,
            maxItems: 4,
          },
          correctIndex: { type: Type.INTEGER },
          tips: { type: Type.STRING },
          workingSteps: { type: Type.STRING },
          explanation: { type: Type.STRING },
        },
        required: ["question", "options", "correctIndex", "tips", "workingSteps", "explanation"],
      },
    },
  });

  const jsonStr = response.text?.trim() || "{}";
  const data = JSON.parse(jsonStr);
  
  return {
    ...data,
    id: Math.random().toString(36).substr(2, 9),
    topic,
    difficulty
  };
};
