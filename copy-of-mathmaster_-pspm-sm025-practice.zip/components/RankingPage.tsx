
import React, { useState } from 'react';
import { Profile, STUDY_GROUPS, AVATARS } from '../types';

interface RankingPageProps {
  userProfile: Profile;
}

const KMM_CAMPUS_MOCK = [
  { name: 'Intan', group: 'Alpha Integrals', avatar: '🦊', correct: 145, total: 160 },
  { name: 'Min Er', group: 'Vector Vanguards', avatar: '👩‍🔬', correct: 138, total: 155 },
  { name: 'Yaya', group: 'Newton\'s Nomads', avatar: '🚀', correct: 122, total: 140 },
  { name: 'Thilah', group: 'Alpha Integrals', avatar: '🧠', correct: 110, total: 125 },
  { name: 'Zarra', group: 'Vector Vanguards', avatar: '🎓', correct: 98, total: 115 },
];

const RankingPage: React.FC<RankingPageProps> = ({ userProfile }) => {
  const [view, setView] = useState<'global' | 'group'>('global');

  const userMastery = userProfile.totalAttempts > 0 
    ? Math.round((userProfile.correctAnswers / userProfile.totalAttempts) * 100) 
    : 0;

  const currentGroupData = STUDY_GROUPS.find(g => g.name === userProfile.group);

  const getLeaderboard = () => {
    let list = [...KMM_CAMPUS_MOCK];
    
    // Add user to the list
    list.push({
      name: userProfile.name || 'You',
      group: userProfile.group,
      avatar: userProfile.avatar,
      correct: userProfile.correctAnswers,
      total: userProfile.totalAttempts
    });

    if (view === 'group' && userProfile.group !== 'None') {
      list = list.filter(item => item.group === userProfile.group);
    }

    return list.sort((a, b) => {
      const masteryA = a.total > 0 ? a.correct / a.total : 0;
      const masteryB = b.total > 0 ? b.correct / b.total : 0;
      return masteryB - masteryA;
    });
  };

  const leaderboard = getLeaderboard();

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="text-center">
        <div className="inline-block bg-red-600 text-white text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-widest mb-4 shadow-sm">
          Official KMM Rankings
        </div>
        <h2 className="text-4xl font-black text-gray-900 mb-2 tracking-tight">Kolej Matrikulasi Melaka</h2>
        <p className="text-gray-500 italic">"Melestari Kecemerlangan Akademik di Bumi Hang Tuah"</p>
      </div>

      <div className="flex justify-center">
        <div className="bg-gray-100 p-1.5 rounded-2xl flex gap-1">
          <button 
            onClick={() => setView('global')}
            className={`px-8 py-2.5 rounded-xl font-bold text-sm transition-all ${view === 'global' ? 'bg-white shadow-sm text-red-600' : 'text-gray-500 hover:text-gray-700'}`}
          >
            KMM Campus
          </button>
          <button 
            onClick={() => setView('group')}
            className={`px-8 py-2.5 rounded-xl font-bold text-sm transition-all ${view === 'group' ? 'bg-white shadow-sm text-red-600' : 'text-gray-500 hover:text-gray-700'}`}
          >
            My Study Group
          </button>
        </div>
      </div>

      <div className="max-w-4xl mx-auto">
        {/* Podium for Top 3 */}
        <div className="flex flex-col md:flex-row items-end justify-center gap-4 mb-12">
          {/* Silver - Rank 2 */}
          {leaderboard[1] && (
            <div className="flex flex-col items-center order-2 md:order-1 flex-1 max-w-[200px]">
              <div className="text-4xl mb-4">{leaderboard[1].avatar}</div>
              <div className="bg-white border-x border-t border-slate-200 w-full h-32 rounded-t-3xl flex flex-col items-center justify-center p-4 text-center">
                <span className="font-bold text-slate-800 truncate w-full">{leaderboard[1].name}</span>
                <span className="text-[10px] font-bold text-red-500">
                  {leaderboard[1].total > 0 ? Math.round((leaderboard[1].correct / leaderboard[1].total) * 100) : 0}%
                </span>
                <div className="mt-4 bg-slate-100 w-12 h-12 rounded-full flex items-center justify-center text-slate-400 font-bold">2</div>
              </div>
            </div>
          )}

          {/* Gold - Rank 1 */}
          {leaderboard[0] && (
            <div className="flex flex-col items-center order-1 md:order-2 flex-1 max-w-[220px]">
              <div className="text-5xl mb-4 relative">
                {leaderboard[0].avatar}
                <div className="absolute -top-4 -right-4 text-2xl animate-bounce">👑</div>
              </div>
              <div className="bg-white border border-amber-200 w-full h-44 rounded-t-[2.5rem] flex flex-col items-center justify-center p-4 text-center shadow-lg shadow-amber-50">
                <span className="font-black text-gray-900 truncate w-full text-lg">{leaderboard[0].name}</span>
                <span className="text-[10px] font-bold text-red-600">
                  {leaderboard[0].total > 0 ? Math.round((leaderboard[0].correct / leaderboard[0].total) * 100) : 0}%
                </span>
                <div className="mt-6 bg-amber-400 w-16 h-16 rounded-full flex items-center justify-center text-white font-black text-xl shadow-md border-4 border-amber-50">1</div>
              </div>
            </div>
          )}

          {/* Bronze - Rank 3 */}
          {leaderboard[2] && (
            <div className="flex flex-col items-center order-3 flex-1 max-w-[200px]">
              <div className="text-4xl mb-4">{leaderboard[2].avatar}</div>
              <div className="bg-white border-x border-t border-orange-100 w-full h-24 rounded-t-3xl flex flex-col items-center justify-center p-4 text-center">
                <span className="font-bold text-slate-800 truncate w-full">{leaderboard[2].name}</span>
                <span className="text-[10px] font-bold text-red-500">
                  {leaderboard[2].total > 0 ? Math.round((leaderboard[2].correct / leaderboard[2].total) * 100) : 0}%
                </span>
                <div className="mt-2 bg-orange-100 w-10 h-10 rounded-full flex items-center justify-center text-orange-400 font-bold">3</div>
              </div>
            </div>
          )}
        </div>

        {/* Remainder List */}
        <div className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden">
          <table className="w-full">
            <tbody className="divide-y divide-gray-50">
              {leaderboard.slice(3).map((item, idx) => (
                <tr key={idx} className={`${item.name === (userProfile.name || 'You') ? 'bg-red-50/50' : 'hover:bg-gray-50'} transition-all`}>
                  <td className="px-8 py-5 w-16 text-center text-sm font-bold text-gray-400">{idx + 4}</td>
                  <td className="px-4 py-5 w-16 text-2xl">{item.avatar}</td>
                  <td className="px-4 py-5">
                    <div className="flex flex-col">
                      <span className="font-bold text-gray-800">{item.name}</span>
                      <span className="text-[10px] font-bold text-gray-400 uppercase">{item.group}</span>
                    </div>
                  </td>
                  <td className="px-8 py-5 text-right">
                    <span className="font-mono font-bold text-red-600">
                      {item.total > 0 ? Math.round((item.correct / item.total) * 100) : 0}%
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {leaderboard.length < 4 && (
             <div className="p-8 text-center text-gray-400 text-sm">
                Keep practicing to see more KMM peers here!
             </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default RankingPage;
