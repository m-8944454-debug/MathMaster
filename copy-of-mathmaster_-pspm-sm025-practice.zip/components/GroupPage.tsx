
import React, { useState, useMemo } from 'react';
import { Profile, STUDY_GROUPS, StudyGroupType, MistakeRecord, DiscussionPost, MathProblem } from '../types';

interface GroupPageProps {
  userProfile: Profile;
  onUpdateProfile: (profile: Profile) => void;
  mistakeNotebook: MistakeRecord[];
  discussionPosts: DiscussionPost[];
  onAddDiscussionPost: (problem: MathProblem) => void;
  onAddComment: (postId: string, text: string) => void;
}

interface Member {
  id: string;
  name: string;
  dailyCount: number;
  totalSolved: number;
  mastery: number;
  avatar: string;
  isYou: boolean;
  status: 'online' | 'offline' | 'studying';
}

const GroupPage: React.FC<GroupPageProps> = ({ 
  userProfile, 
  onUpdateProfile, 
  mistakeNotebook, 
  discussionPosts, 
  onAddDiscussionPost,
  onAddComment
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'members' | 'discussion'>('overview');
  const [groupCode, setGroupCode] = useState('');
  const [error, setError] = useState('');
  const [isSharing, setIsSharing] = useState(false);
  const [newCommentText, setNewCommentText] = useState<{ [key: string]: string }>({});

  const currentGroup = STUDY_GROUPS.find(g => g.name === userProfile.group);

  const handleJoinGroup = () => {
    const foundGroup = STUDY_GROUPS.find(g => g.code.toUpperCase() === groupCode.toUpperCase());
    if (foundGroup) {
      onUpdateProfile({ ...userProfile, group: foundGroup.name });
      setGroupCode('');
      setError('');
    } else {
      setError('Invalid code! Each group has a unique academic key.');
    }
  };

  const leaveGroup = () => {
    onUpdateProfile({ ...userProfile, group: 'None' });
  };

  const handleShareQuestion = (problem: MathProblem) => {
    onAddDiscussionPost(problem);
    setIsSharing(false);
  };

  const handleAddComment = (postId: string) => {
    const text = newCommentText[postId];
    if (text?.trim()) {
      onAddComment(postId, text);
      setNewCommentText({ ...newCommentText, [postId]: '' });
    }
  };

  // Memoized members list to determine leader and stats
  const members: Member[] = useMemo(() => {
    const list: Member[] = [
      { id: '2', name: 'Min Er', dailyCount: 18, totalSolved: 512, mastery: 95, avatar: '👩‍🔬', isYou: false, status: 'online' }, // Highest solved makes her leader
      { id: '1', name: 'Intan', dailyCount: 15, totalSolved: 452, mastery: 88, avatar: '🦊', isYou: false, status: 'studying' },
      { id: '3', name: 'Yaya', dailyCount: 8, totalSolved: 310, mastery: 85, avatar: '🚀', isYou: false, status: 'offline' },
      { id: '4', name: 'Thilah', dailyCount: 6, totalSolved: 285, mastery: 82, avatar: '🧠', isYou: false, status: 'online' },
      { id: '5', name: 'Zarra', dailyCount: 4, totalSolved: 210, mastery: 78, avatar: '🎓', isYou: false, status: 'offline' },
      { 
        id: 'me', 
        name: userProfile.name || 'You', 
        dailyCount: userProfile.dailyCorrectCount, 
        totalSolved: userProfile.correctAnswers,
        mastery: userProfile.totalAttempts > 0 ? Math.round((userProfile.correctAnswers / userProfile.totalAttempts) * 100) : 0,
        avatar: userProfile.avatar, 
        isYou: true,
        status: 'online'
      }
    ];
    return list.sort((a, b) => b.totalSolved - a.totalSolved);
  }, [userProfile]);

  const groupLeader = members[0];
  const dailyChampion = [...members].sort((a, b) => b.dailyCount - a.dailyCount)[0];
  const totalGroupSolved = members.reduce((acc, m) => acc + m.totalSolved, 0);

  if (!currentGroup) {
    return (
      <div className="max-w-xl mx-auto py-12 animate-in fade-in zoom-in-95">
        <div className="text-center mb-10">
          <div className="w-24 h-24 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <svg className="w-12 h-12 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/></svg>
          </div>
          <h2 className="text-3xl font-black text-gray-900 mb-2">Join a Study Group</h2>
          <p className="text-gray-500">Collaborate with peers to master SM025 together.</p>
        </div>

        <div className="bg-white p-8 rounded-3xl shadow-xl border border-gray-100">
          <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-3">Academic Access Code</label>
          <div className="flex gap-2">
            <input 
              type="text" 
              value={groupCode}
              onChange={e => setGroupCode(e.target.value)}
              placeholder="e.g. ALPHA"
              className="flex-grow p-4 rounded-xl border-2 border-gray-100 focus:border-indigo-600 outline-none transition-all uppercase font-mono text-xl"
            />
            <button 
              onClick={handleJoinGroup}
              className="px-8 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 transition-all shadow-lg active:scale-95"
            >
              Unlock
            </button>
          </div>
          {error && <p className="text-sm text-red-500 font-bold mt-4 animate-bounce">{error}</p>}
          
          <div className="mt-8 pt-8 border-t border-gray-50">
            <p className="text-xs text-gray-400 font-medium mb-4">AVAILABLE GROUPS & CODES:</p>
            <div className="space-y-3">
              {STUDY_GROUPS.map(g => (
                <div key={g.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{g.icon}</span>
                    <span className="font-bold text-gray-700">{g.name}</span>
                  </div>
                  <code className="bg-white px-2 py-1 rounded border font-mono text-indigo-600 font-bold">{g.code}</code>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row justify-between items-center gap-6">
        <div className="flex items-center gap-4">
          <div className={`w-16 h-16 rounded-2xl bg-${currentGroup.color}-100 flex items-center justify-center text-3xl shadow-sm`}>
            {currentGroup.icon}
          </div>
          <div>
            <h2 className="text-3xl font-black text-gray-900">{currentGroup.name}</h2>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-xs font-bold text-indigo-500 uppercase tracking-widest bg-indigo-50 px-2 py-0.5 rounded">Active Group</span>
              <button onClick={leaveGroup} className="text-xs text-red-400 hover:text-red-600 font-bold underline">Leave Group</button>
            </div>
          </div>
        </div>

        <div className="flex gap-4">
          <div className="bg-white border p-4 rounded-2xl shadow-sm flex items-center gap-4">
            <div className="relative">
              <span className="text-3xl">{groupLeader.avatar}</span>
              <span className="absolute -top-2 -right-2 text-lg">👑</span>
            </div>
            <div>
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Group Leader</p>
              <p className="font-bold text-gray-800">{groupLeader.name}</p>
            </div>
          </div>

          <div className="bg-indigo-600 text-white p-4 rounded-2xl shadow-lg flex items-center gap-4">
            <div className="text-2xl">🔥</div>
            <div>
              <p className="text-[10px] font-bold text-indigo-200 uppercase tracking-widest">Daily Champ</p>
              <p className="font-bold">{dailyChampion.name}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-gray-200">
        <button 
          onClick={() => setActiveTab('overview')}
          className={`px-8 py-4 font-bold text-sm transition-all border-b-2 ${activeTab === 'overview' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-gray-400 hover:text-gray-600'}`}
        >
          Overview
        </button>
        <button 
          onClick={() => setActiveTab('members')}
          className={`px-8 py-4 font-bold text-sm transition-all border-b-2 ${activeTab === 'members' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-gray-400 hover:text-gray-600'}`}
        >
          Members ({members.length})
        </button>
        <button 
          onClick={() => setActiveTab('discussion')}
          className={`px-8 py-4 font-bold text-sm transition-all border-b-2 ${activeTab === 'discussion' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-gray-400 hover:text-gray-600'}`}
        >
          Discussion
        </button>
      </div>

      {activeTab === 'overview' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1 space-y-6">
            <div className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100">
              <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-6">Group Statistics</h3>
              <div className="space-y-6">
                <div className="flex justify-between items-end">
                  <div>
                    <p className="text-3xl font-black text-gray-900">{totalGroupSolved}</p>
                    <p className="text-[10px] font-bold text-gray-400 uppercase">Total Solved</p>
                  </div>
                  <div className="text-right">
                    <p className="text-xl font-bold text-indigo-600">{Math.round(members.reduce((a, b) => a + b.mastery, 0) / members.length)}%</p>
                    <p className="text-[10px] font-bold text-gray-400 uppercase">Avg Mastery</p>
                  </div>
                </div>
                <div className="pt-6 border-t border-gray-50">
                   <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-4">Daily Goal</h4>
                   <div className="text-center mb-4">
                      <div className="text-4xl font-black text-indigo-600 mb-1">
                        {userProfile.dailyCorrectCount}<span className="text-gray-200 text-2xl">/5</span>
                      </div>
                      <p className="text-[11px] text-gray-500 font-medium">Solve 5 today for <span className="text-indigo-600 font-bold">+50 pts</span></p>
                    </div>
                    <div className="h-2.5 bg-gray-100 rounded-full overflow-hidden">
                      <div 
                        className={`h-full transition-all duration-1000 ${userProfile.dailyGoalReached ? 'bg-green-500' : 'bg-indigo-600'}`}
                        style={{ width: `${Math.min((userProfile.dailyCorrectCount / 5) * 100, 100)}%` }}
                      ></div>
                    </div>
                </div>
              </div>
            </div>

            <div className="bg-indigo-50 p-6 rounded-3xl border border-indigo-100">
              <h4 className="font-bold text-indigo-900 mb-2 flex items-center gap-2">
                <span className="text-lg">📢</span> Group Message
              </h4>
              <p className="text-sm text-indigo-700 italic">"Study hard for the PSPM, {groupLeader.name} is leading our progress! Let's aim for 1000 total solved questions as a team."</p>
            </div>
          </div>

          <div className="lg:col-span-2">
            <div className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
               <div className="px-8 py-6 border-b border-gray-50 bg-gray-50/50 flex justify-between items-center">
                  <h3 className="font-bold text-gray-900">Today's Standings</h3>
                  <span className="text-[10px] font-bold text-indigo-500 bg-white px-2 py-1 rounded shadow-sm">Updated Just Now</span>
               </div>
               <div className="divide-y divide-gray-50">
                  {members.slice(0, 4).map((member, idx) => (
                    <div key={member.id} className={`flex items-center justify-between p-6 hover:bg-gray-50 transition-all ${member.isYou ? 'bg-indigo-50/30' : ''}`}>
                      <div className="flex items-center gap-4">
                        <span className={`text-sm font-bold w-4 ${idx === 0 ? 'text-amber-500' : 'text-gray-300'}`}>{idx + 1}</span>
                        <div className="relative">
                          <span className="text-3xl">{member.avatar}</span>
                          <span className={`absolute bottom-0 right-0 w-3 h-3 border-2 border-white rounded-full ${member.status === 'online' ? 'bg-green-500' : member.status === 'studying' ? 'bg-amber-500' : 'bg-gray-300'}`}></span>
                        </div>
                        <div>
                          <p className="font-bold text-gray-800">
                            {member.name}
                            {member.id === groupLeader.id && <span className="ml-1 text-xs">👑</span>}
                            {member.isYou && <span className="ml-2 text-[10px] font-bold text-indigo-500 uppercase">You</span>}
                          </p>
                          <p className="text-[10px] font-bold text-gray-400 uppercase">{member.status}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-black text-gray-900">{member.dailyCount}</p>
                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-tighter">Daily Score</p>
                      </div>
                    </div>
                  ))}
               </div>
               <button onClick={() => setActiveTab('members')} className="w-full py-4 bg-gray-50 text-indigo-600 text-xs font-bold uppercase tracking-widest hover:bg-gray-100 transition-colors">
                 View All Members
               </button>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'members' && (
        <div className="bg-white rounded-[2rem] shadow-sm border border-gray-100 overflow-hidden animate-in slide-in-from-bottom-4">
          <table className="w-full text-left">
            <thead className="bg-gray-50 text-[10px] uppercase text-gray-400 font-bold">
              <tr>
                <th className="px-8 py-4">Student</th>
                <th className="px-8 py-4">Status</th>
                <th className="px-8 py-4 text-center">Total Solved</th>
                <th className="px-8 py-4 text-right">Mastery</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {members.map((member) => (
                <tr key={member.id} className={`${member.isYou ? 'bg-indigo-50/30' : 'hover:bg-gray-50/50'} transition-colors`}>
                  <td className="px-8 py-5">
                    <div className="flex items-center gap-4">
                      <span className="text-2xl">{member.avatar}</span>
                      <div>
                        <p className="font-bold text-gray-800">
                          {member.name}
                          {member.id === groupLeader.id && <span className="ml-1 text-xs" title="Group Leader">👑</span>}
                        </p>
                        <p className="text-[10px] font-medium text-gray-400">ID: {member.id.substring(0, 4)}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-8 py-5">
                    <span className={`text-[10px] font-bold px-2 py-1 rounded-full uppercase
                      ${member.status === 'online' ? 'bg-green-100 text-green-700' : member.status === 'studying' ? 'bg-amber-100 text-amber-700' : 'bg-gray-100 text-gray-500'}
                    `}>
                      {member.status}
                    </span>
                  </td>
                  <td className="px-8 py-5 text-center font-bold text-gray-700 font-mono">
                    {member.totalSolved}
                  </td>
                  <td className="px-8 py-5 text-right">
                    <span className="font-mono font-bold text-indigo-600">{member.mastery}%</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {activeTab === 'discussion' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-2xl font-black text-gray-900">Discussion Room</h3>
              <p className="text-sm text-gray-500">Post your challenging problems and help others.</p>
            </div>
            <button 
              onClick={() => setIsSharing(true)}
              className="bg-indigo-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-md active:scale-95 flex items-center gap-2"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4"/></svg>
              Share a Question
            </button>
          </div>

          {/* New Post Modal */}
          {isSharing && (
            <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
              <div className="bg-white rounded-3xl max-w-2xl w-full max-h-[80vh] overflow-y-auto p-8 animate-in zoom-in-95 duration-200">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-2xl font-black text-gray-900">Select Question</h3>
                  <button onClick={() => setIsSharing(false)} className="text-gray-400 hover:text-gray-600">
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"/></svg>
                  </button>
                </div>

                {mistakeNotebook.length === 0 ? (
                  <div className="text-center py-12 bg-gray-50 rounded-2xl border-2 border-dashed border-gray-200">
                    <p className="text-gray-500 font-bold mb-2">Notebook is empty!</p>
                    <p className="text-xs text-gray-400">Add questions to your notebook first.</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {mistakeNotebook.map(record => (
                      <button 
                        key={record.problem.id}
                        onClick={() => handleShareQuestion(record.problem)}
                        className="w-full text-left p-4 rounded-xl border border-gray-100 hover:border-indigo-200 hover:bg-indigo-50/50 transition-all flex items-center justify-between group"
                      >
                        <div className="flex-1 pr-4 truncate">
                          <p className="text-xs font-bold text-indigo-500 uppercase mb-1">{record.problem.topic}</p>
                          <p className="font-medium text-gray-700 truncate">{record.problem.question}</p>
                        </div>
                        <span className="text-indigo-600 opacity-0 group-hover:opacity-100 font-bold text-xs uppercase">Share →</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Discussion Feed */}
          <div className="space-y-6">
            {discussionPosts.length === 0 ? (
              <div className="text-center py-20 bg-gray-50 rounded-[2.5rem] border-2 border-dashed border-gray-200">
                <span className="text-5xl block mb-4">💬</span>
                <h4 className="text-xl font-bold text-gray-800">No discussions yet</h4>
                <p className="text-gray-500 text-sm mt-2">Be the first to share a challenging problem!</p>
              </div>
            ) : (
              discussionPosts.map(post => (
                <div key={post.id} className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden flex flex-col md:flex-row">
                  <div className="md:w-3/5 p-8 border-b md:border-b-0 md:border-r border-gray-100 bg-slate-50/30">
                    <div className="flex items-center gap-3 mb-6">
                      <span className="text-3xl">{post.authorAvatar}</span>
                      <div>
                        <p className="font-black text-gray-900">{post.authorName}</p>
                        <p className="text-[10px] font-bold text-gray-400 uppercase">{new Date(post.timestamp).toLocaleString()}</p>
                      </div>
                    </div>
                    
                    <div className="bg-white p-6 rounded-2xl border border-indigo-50 shadow-sm mb-6">
                      <span className="text-[10px] font-bold text-indigo-500 uppercase tracking-widest block mb-2">{post.problem.topic}</span>
                      <p className="text-lg font-medium text-gray-800 leading-relaxed">{post.problem.question}</p>
                    </div>

                    <details className="group">
                      <summary className="text-xs font-bold text-indigo-600 cursor-pointer hover:underline list-none flex items-center gap-1">
                        <svg className="w-4 h-4 transition-transform group-open:rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"/></svg>
                        View Solution
                      </summary>
                      <div className="mt-4 p-4 bg-indigo-50/50 rounded-xl border border-indigo-100 text-[11px] font-mono text-indigo-900 whitespace-pre-wrap">
                        {post.problem.workingSteps}
                      </div>
                    </details>
                  </div>

                  <div className="md:w-2/5 p-8 bg-white flex flex-col">
                    <h4 className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-4">Discussion ({post.comments.length})</h4>
                    <div className="flex-1 space-y-4 mb-6 overflow-y-auto max-h-[300px] pr-2">
                      {post.comments.length === 0 ? (
                        <p className="text-xs text-gray-400 italic py-4">Start the conversation!</p>
                      ) : (
                        post.comments.map(comment => (
                          <div key={comment.id} className="flex gap-3 animate-in slide-in-from-bottom-2">
                            <span className="text-xl flex-shrink-0">{comment.authorAvatar}</span>
                            <div className="bg-gray-50 p-3 rounded-2xl rounded-tl-none flex-1">
                              <p className="text-[10px] font-bold text-indigo-600">{comment.authorName}</p>
                              <p className="text-sm text-gray-700 leading-snug">{comment.text}</p>
                            </div>
                          </div>
                        ))
                      )}
                    </div>

                    <div className="mt-auto flex gap-2">
                        <input 
                          type="text" 
                          value={newCommentText[post.id] || ''}
                          onChange={(e) => setNewCommentText({ ...newCommentText, [post.id]: e.target.value })}
                          placeholder="Type a hint..."
                          className="flex-grow p-3 bg-gray-50 rounded-xl border border-transparent focus:border-indigo-600 outline-none text-sm"
                          onKeyDown={(e) => e.key === 'Enter' && handleAddComment(post.id)}
                        />
                        <button 
                          onClick={() => handleAddComment(post.id)}
                          className="bg-indigo-600 text-white p-3 rounded-xl hover:bg-indigo-700"
                        >
                          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>
                        </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default GroupPage;
