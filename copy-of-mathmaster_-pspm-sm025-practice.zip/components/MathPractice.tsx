
import React, { useState, useEffect, useCallback } from 'react';
import { generateMathProblem } from '../services/geminiService';
import { MathProblem, Difficulty } from '../types';

interface MathPracticeProps {
  onCorrectAnswer: () => void;
  onMistake: (problem: MathProblem) => void;
  onIncorrectAttempt: () => void;
}

const TOPICS = ["Numerical Solution", "Integration", "Vector"];

const MathPractice: React.FC<MathPracticeProps> = ({ onCorrectAnswer, onMistake, onIncorrectAttempt }) => {
  const [problem, setProblem] = useState<MathProblem | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [selectedTopic, setSelectedTopic] = useState<string>(TOPICS[0]);
  const [selectedDifficulty, setSelectedDifficulty] = useState<Difficulty>(1);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isChecked, setIsChecked] = useState<boolean>(false);
  const [wrongAttempts, setWrongAttempts] = useState<number>(0);
  const [isCorrect, setIsCorrect] = useState<boolean>(false);
  const [activeHelp, setActiveHelp] = useState<'tips' | 'steps' | 'answer' | null>(null);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  const loadNewProblem = useCallback(async () => {
    setLoading(true);
    setProblem(null);
    setSelectedOption(null);
    setIsChecked(false);
    setWrongAttempts(0);
    setIsCorrect(false);
    setActiveHelp(null);
    setStatusMessage(null);
    try {
      const newProblem = await generateMathProblem(selectedTopic, selectedDifficulty);
      setProblem(newProblem);
    } catch (error) {
      console.error("Failed to fetch problem", error);
      setStatusMessage("Failed to load problem. Please check your connection.");
    } finally {
      setLoading(false);
    }
  }, [selectedTopic, selectedDifficulty]);

  const handleCheck = () => {
    if (selectedOption === null || !problem) return;
    
    const correct = selectedOption === problem.correctIndex;
    setIsChecked(true);

    if (correct) {
      setIsCorrect(true);
      setStatusMessage("Perfect! That is correct.");
      onCorrectAnswer();
    } else {
      onIncorrectAttempt();
      const newWrongAttempts = wrongAttempts + 1;
      setWrongAttempts(newWrongAttempts);
      setStatusMessage("Incorrect. Please try again!");
      
      if (newWrongAttempts === 2) {
        onMistake(problem);
      }

      setTimeout(() => {
        if (!isCorrect) setIsChecked(false);
      }, 1200);
    }
  };

  const getDifficultyStars = (level: number) => "★".repeat(level) + "☆".repeat(3 - level);

  if (!problem && !loading) {
    return (
      <div className="max-w-xl mx-auto py-12 text-center bg-white rounded-3xl shadow-sm border p-8 animate-in fade-in zoom-in-95">
        <h2 className="text-3xl font-extrabold text-gray-900 mb-2">Practice Session</h2>
        <p className="text-gray-500 mb-8">Select a topic to start practicing for SM025.</p>
        
        <div className="space-y-6 text-left">
          <div>
            <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-3">Target Topic</label>
            <div className="grid grid-cols-1 gap-2">
              {TOPICS.map(t => (
                <button
                  key={t}
                  onClick={() => setSelectedTopic(t)}
                  className={`p-4 rounded-xl border-2 transition-all text-left flex items-center justify-between font-semibold ${selectedTopic === t ? 'border-indigo-600 bg-indigo-50 text-indigo-700' : 'border-gray-100 hover:border-gray-200 text-gray-600'}`}
                >
                  {t}
                  {selectedTopic === t && <div className="w-2 h-2 rounded-full bg-indigo-600"></div>}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-3">Difficulty Level</label>
            <div className="flex gap-3">
              {[1, 2, 3].map(d => (
                <button
                  key={d}
                  onClick={() => setSelectedDifficulty(d as Difficulty)}
                  className={`flex-1 p-4 rounded-xl border-2 transition-all text-center flex flex-col items-center gap-1 ${selectedDifficulty === d ? 'border-indigo-600 bg-indigo-50 text-indigo-700' : 'border-gray-100 hover:border-gray-200 text-gray-400'}`}
                >
                  <span className="text-xl font-mono">{getDifficultyStars(d)}</span>
                  <span className="text-[10px] uppercase font-bold">{d === 1 ? 'Beginner' : d === 2 ? 'Intermediate' : 'Advanced'}</span>
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={loadNewProblem}
            className="w-full bg-indigo-600 text-white font-bold py-5 rounded-2xl shadow-lg hover:bg-indigo-700 transition-all active:scale-95 flex items-center justify-center gap-2 mt-4"
          >
            Start Session
          </button>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-24 animate-in fade-in">
        <div className="w-16 h-16 border-4 border-indigo-100 border-t-indigo-600 rounded-full animate-spin mb-6"></div>
        <h3 className="text-xl font-bold text-gray-900">Preparing Problem...</h3>
        <p className="text-gray-400 text-sm mt-2">Connecting to AI Tutor</p>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto space-y-6 animate-in slide-in-from-bottom-4">
      <div className="bg-white px-8 py-4 rounded-2xl shadow-sm border border-gray-100 flex items-center justify-between">
        <div className="flex items-center gap-6">
          <div>
            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest block">Topic</span>
            <span className="text-sm font-bold text-indigo-600">{selectedTopic}</span>
          </div>
          <div>
            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest block">Level</span>
            <span className="text-amber-500 font-mono">{getDifficultyStars(selectedDifficulty)}</span>
          </div>
        </div>
        <button 
          onClick={() => setProblem(null)}
          className="text-[10px] font-bold text-gray-400 hover:text-red-500 uppercase tracking-widest"
        >
          Quit
        </button>
      </div>

      <div className="bg-white rounded-[2rem] shadow-xl overflow-hidden border border-gray-100 p-8 md:p-12">
        <div className="mb-10">
          <h2 className="text-2xl font-medium text-gray-800 leading-relaxed whitespace-pre-wrap">
            {problem?.question}
          </h2>
        </div>

        <div className="space-y-4 mb-10">
          {problem?.options.map((option, idx) => (
            <button
              key={idx}
              disabled={isCorrect || isChecked}
              onClick={() => setSelectedOption(idx)}
              className={`w-full text-left p-6 rounded-2xl border-2 transition-all flex items-center justify-between
                ${selectedOption === idx 
                  ? isCorrect 
                    ? 'border-green-500 bg-green-50' 
                    : isChecked 
                      ? 'border-red-500 bg-red-50' 
                      : 'border-indigo-600 bg-indigo-50 ring-2 ring-indigo-200' 
                  : isCorrect && idx === problem.correctIndex
                    ? 'border-green-500 bg-green-50'
                    : 'border-gray-100 hover:border-indigo-200'
                }
              `}
            >
              <div className="flex items-center gap-5">
                <span className={`w-9 h-9 flex items-center justify-center rounded-full text-sm font-bold border-2
                  ${selectedOption === idx ? 'bg-indigo-600 text-white border-indigo-600' : 'text-gray-400 border-gray-200'}
                `}>
                  {String.fromCharCode(65 + idx)}
                </span>
                <span className="text-lg text-gray-700 font-medium">{option}</span>
              </div>
            </button>
          ))}
        </div>

        {statusMessage && (
          <div className={`mb-8 p-6 rounded-2xl border text-center font-bold animate-in fade-in
            ${isCorrect ? 'bg-green-50 border-green-200 text-green-700' : 'bg-red-50 border-red-200 text-red-700'}`}>
            {statusMessage}
            {!isCorrect && <span className="block text-xs mt-1 opacity-70">Attempt #{wrongAttempts + 1}</span>}
          </div>
        )}

        {wrongAttempts >= 2 && !isCorrect && (
          <div className="mb-8 p-8 bg-indigo-50 border border-indigo-100 rounded-[1.5rem] animate-in slide-in-from-bottom-6">
            <h4 className="font-bold text-indigo-900 mb-4 flex items-center gap-2">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-8-3a1 1 0 00-.867.5 1 1 0 11-1.731-1A3 3 0 0113 8a3.001 3.001 0 01-2 2.83V11a1 1 0 11-2 0v-1a1 1 0 011-1 1 1 0 100-2zm0 8a1 1 0 100-2 1 1 0 000 2z" clipRule="evenodd" />
              </svg>
              Saved to Mistake Notebook:
            </h4>
            
            <div className="flex flex-wrap gap-2 mb-6">
              <button onClick={() => setActiveHelp('tips')} className={`flex-1 py-3 px-4 rounded-xl text-xs font-bold transition-all border-2 ${activeHelp === 'tips' ? 'bg-indigo-600 border-indigo-600 text-white' : 'bg-white border-white text-indigo-600'}`}>Get Tip</button>
              <button onClick={() => setActiveHelp('steps')} className={`flex-1 py-3 px-4 rounded-xl text-xs font-bold transition-all border-2 ${activeHelp === 'steps' ? 'bg-indigo-600 border-indigo-600 text-white' : 'bg-white border-white text-indigo-600'}`}>Show Steps</button>
              <button onClick={() => setActiveHelp('answer')} className={`flex-1 py-3 px-4 rounded-xl text-xs font-bold transition-all border-2 ${activeHelp === 'answer' ? 'bg-indigo-600 border-indigo-600 text-white' : 'bg-white border-white text-indigo-600'}`}>Reveal Answer</button>
            </div>
            
            {activeHelp && (
              <div className="p-6 bg-white rounded-2xl border border-indigo-100 text-sm text-gray-700 shadow-sm animate-in fade-in">
                {activeHelp === 'tips' && <p>{problem?.tips}</p>}
                {activeHelp === 'steps' && <div className="whitespace-pre-wrap font-mono text-xs overflow-x-auto">{problem?.workingSteps}</div>}
                {activeHelp === 'answer' && <p className="font-bold text-lg">The correct option is {String.fromCharCode(65 + (problem?.correctIndex ?? 0))}</p>}
              </div>
            )}
          </div>
        )}

        {isCorrect && (
          <div className="mb-10 p-8 bg-green-50 border border-green-100 rounded-[1.5rem] animate-in zoom-in-95">
            <h4 className="font-bold text-green-900 text-lg mb-2 text-center">Mastered!</h4>
            <p className="text-green-800/80 mb-4 text-center">{problem?.explanation}</p>
            <div className="p-4 bg-white/50 rounded-xl border border-green-200 text-xs font-mono whitespace-pre-wrap overflow-x-auto">
              {problem?.workingSteps}
            </div>
          </div>
        )}

        <div className="flex gap-4">
          {!isCorrect ? (
            <button
              disabled={selectedOption === null || isChecked}
              onClick={handleCheck}
              className="flex-grow bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-extrabold py-5 rounded-2xl shadow-xl transition-all active:scale-95"
            >
              {isChecked ? "Checking..." : "Submit Answer"}
            </button>
          ) : (
            <button
              onClick={loadNewProblem}
              className="flex-grow bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold py-5 rounded-2xl shadow-xl transition-all flex items-center justify-center gap-3 active:scale-95"
            >
              <span>Next Question</span>
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 5l7 7-7 7M5 5l7 7-7 7" />
              </svg>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default MathPractice;
