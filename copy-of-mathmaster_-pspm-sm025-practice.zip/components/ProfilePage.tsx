
import React, { useState } from 'react';
import { Profile, StudyGroupType, STUDY_GROUPS, AVATARS } from '../types';

interface ProfilePageProps {
  profile: Profile;
  onUpdateProfile: (profile: Profile) => void;
  onClearData: () => void;
}

const ProfilePage: React.FC<ProfilePageProps> = ({ profile, onUpdateProfile, onClearData }) => {
  const [name, setName] = useState(profile.name);
  const [motivation, setMotivation] = useState(profile.motivation);
  const [avatar, setAvatar] = useState(profile.avatar);
  const [groupCode, setGroupCode] = useState('');
  const [isEditing, setIsEditing] = useState(!profile.name);
  const [showConfirmClear, setShowConfirmClear] = useState(false);
  const [error, setError] = useState('');

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateProfile({ 
      ...profile,
      name, 
      motivation, 
      avatar
    });
    setIsEditing(false);
  };

  const handleJoinGroup = () => {
    const foundGroup = STUDY_GROUPS.find(g => g.code.toUpperCase() === groupCode.toUpperCase());
    if (foundGroup) {
      onUpdateProfile({ ...profile, group: foundGroup.name });
      setGroupCode('');
      setError('');
    } else {
      setError('Invalid group code. Ask your friends for the right one!');
    }
  };

  const mastery = profile.totalAttempts > 0 
    ? Math.round((profile.correctAnswers / profile.totalAttempts) * 100) 
    : 0;

  const currentGroup = STUDY_GROUPS.find(g => g.name === profile.group);

  return (
    <div className="max-w-2xl mx-auto py-6 animate-in fade-in duration-500">
      <div className="bg-white rounded-3xl shadow-xl border border-gray-100 overflow-hidden">
        <div className="bg-indigo-600 h-32 relative">
          <div className="absolute -bottom-12 left-8">
            <div className="w-24 h-24 rounded-2xl bg-white shadow-lg flex items-center justify-center text-5xl border-4 border-white">
              {avatar}
            </div>
          </div>
        </div>

        <div className="pt-16 pb-12 px-8">
          {isEditing ? (
            <form onSubmit={handleSave} className="space-y-8">
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-4">Choose Your Avatar</label>
                <div className="grid grid-cols-4 gap-3">
                  {AVATARS.map(a => (
                    <button
                      key={a}
                      type="button"
                      onClick={() => setAvatar(a)}
                      className={`text-3xl p-3 rounded-xl border-2 transition-all ${avatar === a ? 'border-indigo-600 bg-indigo-50' : 'border-gray-50 hover:border-gray-100'}`}
                    >
                      {a}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">Student Name</label>
                <input 
                  type="text" 
                  value={name}
                  onChange={e => setName(e.target.value)}
                  placeholder="Enter your name"
                  className="w-full p-4 rounded-xl border-2 border-gray-100 focus:border-indigo-600 outline-none transition-all font-semibold"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">My Motivation</label>
                <textarea 
                  value={motivation}
                  onChange={e => setMotivation(e.target.value)}
                  placeholder="Why are you studying for SM025?"
                  className="w-full p-4 rounded-xl border-2 border-gray-100 focus:border-indigo-600 outline-none transition-all font-medium h-24 resize-none"
                />
              </div>
              
              <button 
                type="submit"
                className="w-full py-4 bg-indigo-600 text-white font-bold rounded-2xl shadow-lg hover:bg-indigo-700 transition-all"
              >
                Save My Profile
              </button>
            </form>
          ) : (
            <div className="space-y-8">
              <div className="flex justify-between items-start">
                <div>
                  <h2 className="text-3xl font-extrabold text-gray-900">{name}</h2>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {currentGroup ? (
                      <span className={`bg-${currentGroup.color}-50 text-${currentGroup.color}-700 text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-widest flex items-center gap-1`}>
                        <span className="text-sm">{currentGroup.icon}</span> {currentGroup.name}
                      </span>
                    ) : (
                      <span className="bg-gray-50 text-gray-500 text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-widest">No Group</span>
                    )}
                    <span className="bg-amber-50 text-amber-600 text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-widest">{mastery}% Mastery</span>
                  </div>
                </div>
                <button 
                  onClick={() => setIsEditing(true)}
                  className="text-xs font-bold text-indigo-600 hover:text-indigo-800 underline uppercase tracking-widest"
                >
                  Edit Profile
                </button>
              </div>

              {/* Group Joining Section */}
              {!currentGroup && (
                <div className="p-6 bg-slate-50 rounded-2xl border-2 border-dashed border-slate-200">
                  <h4 className="font-bold text-slate-800 mb-1">Enter Group Code</h4>
                  <p className="text-xs text-slate-500 mb-4">Join your friends' study group to compete together.</p>
                  <div className="flex gap-2">
                    <input 
                      type="text" 
                      value={groupCode}
                      onChange={e => setGroupCode(e.target.value)}
                      placeholder="e.g. ALPHA"
                      className="flex-grow p-3 rounded-xl border-2 border-white focus:border-indigo-600 outline-none transition-all uppercase font-mono"
                    />
                    <button 
                      onClick={handleJoinGroup}
                      className="px-6 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 transition-all"
                    >
                      Join
                    </button>
                  </div>
                  {error && <p className="text-[10px] text-red-500 font-bold mt-2">{error}</p>}
                </div>
              )}

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-gray-50 p-6 rounded-2xl border border-gray-100 text-center">
                  <div className="text-2xl font-black text-gray-800">{profile.correctAnswers}</div>
                  <div className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Correct Answers</div>
                </div>
                <div className="bg-gray-50 p-6 rounded-2xl border border-gray-100 text-center">
                  <div className="text-2xl font-black text-gray-800">{profile.totalAttempts}</div>
                  <div className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Total Attempts</div>
                </div>
              </div>

              {motivation && (
                <div className="bg-indigo-50 p-6 rounded-2xl border border-indigo-100">
                  <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest block mb-2">Motivation Quote</span>
                  <p className="text-indigo-800 text-lg italic font-medium">"{motivation}"</p>
                </div>
              )}

              <div className="pt-8 border-t border-gray-100">
                {!showConfirmClear ? (
                  <button 
                    onClick={() => setShowConfirmClear(true)}
                    className="text-red-400 hover:text-red-600 text-xs font-bold uppercase tracking-widest transition-colors flex items-center gap-1"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                    Clear All My Data
                  </button>
                ) : (
                  <div className="bg-red-50 p-6 rounded-2xl border border-red-200">
                    <p className="text-red-800 font-bold mb-4">Resetting will clear points, group, and notebook. Proceed?</p>
                    <div className="flex gap-3">
                      <button onClick={onClearData} className="flex-1 py-3 bg-red-600 text-white font-bold rounded-xl">Reset</button>
                      <button onClick={() => setShowConfirmClear(false)} className="flex-1 py-3 bg-white text-gray-600 font-bold rounded-xl border">Cancel</button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;
